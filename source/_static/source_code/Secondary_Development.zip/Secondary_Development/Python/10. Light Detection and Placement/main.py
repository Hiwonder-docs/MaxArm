import time
from machine import Pin,ADC
from Buzzer import Buzzer
from espmax import ESPMax
from PWMServo import PWMServo
from BusServo import BusServo
from RobotControl import RobotControl
from SuctionNozzle import SuctionNozzle

# Light sensor triggered placement (光线感应摆放)

pwm = PWMServo()
buzzer = Buzzer()
bus_servo = BusServo()
arm = ESPMax(bus_servo)
robot = RobotControl()
nozzle = SuctionNozzle()

# Initialize light sensor (初始化光线传感器)
light_sendor = ADC(Pin(32)) 
light_sendor.atten(ADC.ATTN_11DB)
light_sendor.width(ADC.WIDTH_10BIT)

if __name__ == '__main__':
  arm.go_home() #Reset arm to home position (机械臂复位，回到初始位置)
  nozzle.set_angle(0,1000) #Set nozzle angle to 0 (吸嘴角度置0)
  time.sleep_ms(2000)
  num = 0 #Block count variable (木块计数变量)
  angle = [12, 35, 55] #Angle compensation (角度补偿)
  while True:
    light = light_sendor.read() #Read light sensor (光线传感器检测函数)
    print(light)
    if light > 900: # Light sensor blocked (光线传感器被挡)
      print('num:',num+1)
      buzzer.setBuzzer(100) #Beep buzzer once (蜂鸣器响一下)
      time.sleep_ms(500)
      arm.set_position((0,-165,100),1200) #Move arm above pickup position and wait 2 seconds before picking up (机械臂移动到吸取位置上方，等待2秒后吸取)
      time.sleep_ms(2000)
      arm.set_position((0,-165,86),600) #Suction the color block (吸取色块)
      nozzle.on() # Turn on the pump (打开气泵)
      time.sleep_ms(1000)
      arm.set_position((0,-165,180),1000) #Lift arm (机械臂抬起来)
      time.sleep_ms(1000)
      arm.set_position((120,-20-60*num,180),1500) # Move above placement position (移动到放置位置上方)
      nozzle.set_angle(angle[num],1500) #Set angle compensation to place block straight (设置角度补偿，使木块放正)
      time.sleep_ms(1500)
      arm.set_position((120,-20-60*num,88),1000) #Place block (放置木块)
      time.sleep_ms(1200)
      nozzle.off() # Turn off the pump (关闭气泵)
      arm.set_position((120,-20-60*num,200),1000) # Lift arm (机械臂抬起来)
      time.sleep_ms(1000)
      arm.go_home() #Reset arm to home position (机械臂复位，回到初始位置)
      nozzle.set_angle(0,1800) #Set nozzle angle to 0 (吸嘴角度置0)
      time.sleep_ms(2000)
      num += 1      #Increment block count (木块计数变量加1)
      if num >= 3: 
        num = 0
        buzzer.setBuzzer(80) #Beep buzzer once (蜂鸣器响一下)
        time.sleep_ms(100)
        buzzer.setBuzzer(80) #Beep buzzer once (蜂鸣器响一下)
      
    else:
      time.sleep_ms(300)
      






