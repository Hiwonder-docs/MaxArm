import time
from Buzzer import Buzzer
from espmax import ESPMax
from PWMServo import PWMServo
from BusServo import BusServo
from Touch_sensor import TOUCH
from RobotControl import RobotControl
from SuctionNozzle import SuctionNozzle

# Touch placement (触控摆放)

touch = TOUCH()
pwm = PWMServo()
buzzer = Buzzer()
bus_servo = BusServo()
arm = ESPMax(bus_servo)
robot = RobotControl()
nozzle = SuctionNozzle()

if __name__ == '__main__':
  arm.go_home() #Reset arm to initial position (机械臂复位，回到初始位置)
  nozzle.set_angle(0,1000) #Set suction nozzle angle to 0 (吸嘴角度置0)
  time.sleep_ms(2000)
  num = 0 #Block counter variable (木块计数变量)
  angle = [-8,-30,-50] #Angle compensation (角度补偿)
  while True:
    touch.run_loop() #Touch sensor detection function (触摸传感器检测函数)
    if touch.down_up(): #Short press on touch sensor (短按触摸传感器)
      print('num:',num+1)
      buzzer.setBuzzer(100) #Buzzer beeps once (蜂鸣器响一下)
      arm.set_position((0,-160,100),1200) #Move arm above pickup position, wait 2s before suction (机械臂移动到吸取位置上方，等待2秒后吸取)
      time.sleep_ms(2000)
      arm.set_position((0,-160,85),600) #Suction the color block (吸取色块)
      nozzle.on() # Turn on the pump (打开气泵)
      time.sleep_ms(1000)
      arm.set_position((0,-160,180),1000) #Lift the arm (机械臂抬起来)
      time.sleep_ms(1000)
      arm.set_position((120,-20-60*num,180),1500) # Move above placement position (移动到放置位置上方)
      nozzle.set_angle(angle[num],1500) #Apply angle compensation to align block (设置角度补偿，使木块放正)
      time.sleep_ms(1500)
      arm.set_position((120,-20-60*num,83+num),1000) #Place the block (放置木块)
      time.sleep_ms(1200)
      nozzle.off() # Turn off pump (关闭气泵)
      arm.set_position((120,-20-60*num,200),1000) # Lift the arm (机械臂抬起来)
      time.sleep_ms(1000)
      arm.go_home() #Reset arm to initial position (机械臂复位，回到初始位置)
      nozzle.set_angle(0,1800) #Reset suction nozzle angle to 0 (吸嘴角度置0)
      time.sleep_ms(2000)
      num += 1      #Increase block counter (木块计数变量加1)
      if num >= 3: 
        num = 0
        buzzer.setBuzzer(80) #Buzzer beeps once (蜂鸣器响一下)
        time.sleep_ms(100)
        buzzer.setBuzzer(80) #Buzzer beeps once (蜂鸣器响一下)
      
    else:
      time.sleep_ms(300)
      
