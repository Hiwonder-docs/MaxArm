import time
from machine import Pin,ADC
from Buzzer import Buzzer
from espmax import ESPMax
from PWMServo import PWMServo
from BusServo import BusServo
from RobotControl import RobotControl
from SuctionNozzle import SuctionNozzle

# Sound-activated placement (声音感应摆放)

pwm = PWMServo()
buzzer = Buzzer()
bus_servo = BusServo()
arm = ESPMax(bus_servo)
robot = RobotControl()
nozzle = SuctionNozzle()

# Initialize sound sensor (初始化声音传感器)
sound_sendor = ADC(Pin(32)) 
sound_sendor.atten(ADC.ATTN_11DB)
sound_sendor.width(ADC.WIDTH_10BIT)

if __name__ == '__main__':
  arm.go_home() #Reset arm to home position (机械臂复位，回到初始位置)
  nozzle.set_angle(0,1000) #Set nozzle angle to 0 (吸嘴角度置0)
  time.sleep_ms(2000)
  angle = [12, 35, 55] #Angle compensation for placement (角度补偿)
  time_ms = time.ticks_ms()
  num_st = False
  num = 0
  
  while True:
    sound = sound_sendor.read() #Read sound sensor value (声音传感器检测函数)
    
    if sound > 50: 
      if num == 0 or (time.ticks_ms()-time_ms) < 1000:
        time_ms = time.ticks_ms()
        time.sleep_ms(80)
        num += 1
  
    if num and (time.ticks_ms()-time_ms) > 1500:
      num = 3 if num > 3 else num
      num_st = True
      print(num)

    if num_st: 
      buzzer.setBuzzer(100) # Buzz once (蜂鸣器响一下)
      arm.set_position((0,-160,100),1200) # Move arm above pickup position and wait 2 seconds before picking up (机械臂移动到吸取位置上方，等待2秒后吸取)
      time.sleep_ms(2000)
      arm.set_position((0,-160,86),600) # Suction the color block (吸取色块)
      nozzle.on() # Turn on the pump (打开气泵)
      time.sleep_ms(1000)
      arm.set_position((0,-160,180),1000) # Lift arm (机械臂抬起来)
      time.sleep_ms(1000)
      arm.set_position((120,-20-60*(num-1),180),1500) # Reset arm to home position (机械臂复位，回到初始位置)
      nozzle.set_angle(angle[(num-1)],1500) # Set angle compensation (设置角度补偿，使木块放正)
      time.sleep_ms(1500)
      arm.set_position((120,-20-60*(num-1),88),1000) # Place block (放置木块)
      time.sleep_ms(1200)
      nozzle.off() # Turn off the pump (关闭气泵)
      arm.set_position((120,-20-60*(num-1),200),1000) # Lift arm (机械臂抬起来)
      time.sleep_ms(1000)
      arm.go_home() # Reset arm to home position (机械臂复位，回到初始位置)
      nozzle.set_angle(0,1800) # Reset nozzle angle to 0 (吸嘴角度置0)
      time.sleep_ms(2000)
      num_st = False
      num = 0
      
    else:
      time.sleep_ms(20)






