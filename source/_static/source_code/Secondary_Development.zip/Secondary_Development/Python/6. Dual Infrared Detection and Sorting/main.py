import time
from Buzzer import Buzzer
from espmax import ESPMax
from PWMServo import PWMServo
from BusServo import BusServo
from Infrared_sensor import INFRARED
from RobotControl import RobotControl
from SuctionNozzle import SuctionNozzle

#Dual infrared detection and sorting (双红外检测分拣)

pwm = PWMServo()
buzzer = Buzzer()
bus_servo = BusServo()
arm = ESPMax(bus_servo)
robot = RobotControl()
nozzle = SuctionNozzle()

infrared_left = INFRARED(23)
infrared_right = INFRARED(32)
infrared_left.set_long_close_time(500)
infrared_right.set_long_close_time(500)

if __name__ == '__main__':
  arm.go_home() # Arm reset to home position (机械臂复位，回到初始位置)
  nozzle.set_angle(0,1000) #Set nozzle angle to 0 (吸嘴角度置0)
  time.sleep_ms(2000)
  time_ = time.time()
  while True:
    infrared_left.run_loop() # Run sensor detection function (传感器检测函数)
    time.sleep(0.05)
    infrared_right.run_loop()
    
    if infrared_left.close_long(): # Left sensor detects block (左边传感器检测到木块)
      print("infrared_left")
      buzzer.setBuzzer(100) #Set buzzer on for 100 ms (设置蜂鸣器响100ms)
      arm.set_position((70,-165,120),1500)
      time.sleep_ms(1000) # Wait for 1000 ms (等待1000ms)
      arm.set_position((70,-165,86),800) #Suction the color block (吸取色块)
      nozzle.on()  #Turn on the pump (打开气泵)
      time.sleep_ms(1000)
      arm.set_position((70,-165,200),1000) #Lift up (抬起来)
      time.sleep_ms(1000)
      arm.set_position((150,-35,200),800) #Move above placing area (到达放置区上方)
      nozzle.set_angle(15,500)
      time.sleep_ms(500)
      arm.set_position((150,-35,90),800) #Move to placing area (到放置区)
      time.sleep_ms(800)
      arm.set_position((150,10,88),500) #Shift to place (移动一下进行放置)
      time.sleep_ms(500)
      nozzle.off()  #Turn off the pump (关闭气泵)
      arm.set_position((150,10,200),1000) #Lift up (抬起来)
      time.sleep_ms(1000)
      arm.go_home() #Arm reset to home position (机械臂复位，回到初始位置)
      nozzle.set_angle(0,2000)
      time.sleep_ms(2000)
    
    elif infrared_right.close_long(): # Right sensor detects block (右边传感器检测到木块)
      print("infrared_right")
      buzzer.setBuzzer(100) #Set buzzer on for 100 ms (设置蜂鸣器响100ms)
      arm.set_position((-70,-165,120),1500)
      time.sleep_ms(1000) #Set buzzer on for 100 ms (设置蜂鸣器响100ms)
      arm.set_position((-70,-165,86),800) #Suction the color block (吸取色块)
      nozzle.on()  #Turn on the pump (打开气泵)
      time.sleep_ms(1000)
      arm.set_position((-70,-165,200),1000) #Lift up (抬起来)
      time.sleep_ms(1000)
      arm.set_position((-150,-35,200),800) #Move above placing area (到达放置区上方)
      nozzle.set_angle(-15,500)
      time.sleep_ms(500)
      arm.set_position((-150,-35,90),800) #Move to placing area (到放置区)
      time.sleep_ms(800)
      arm.set_position((-150,10,88),500) #Shift to place (移动一下进行放置)
      time.sleep_ms(500)
      nozzle.off()  #Turn off the pump (关闭气泵)
      arm.set_position((-150,10,200),1000) #Lift up (抬起来)
      time.sleep_ms(1000)
      arm.go_home() #Arm reset to home position (机械臂复位，回到初始位置)
      nozzle.set_angle(0,2000)
      time.sleep_ms(2000)
    
    else:
      time.sleep(0.1) #延时

















