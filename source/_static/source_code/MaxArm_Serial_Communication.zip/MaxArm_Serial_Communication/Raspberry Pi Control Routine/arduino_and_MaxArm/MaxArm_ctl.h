/**
 * @file MaxArm_ctl.h
 * @author Wu TongXing
 * @brief Arduino communication with MaxArm (Arduino与MaxArm通讯)
 * @version 0.1
 * @date 2024-02-24
 */

#ifndef MAXARM_CTL_H
#define MAXARM_CTL_H

#include <Arduino.h>
#include "SoftwareSerial.h" //Software serial library (软串口库)

#define rxPin 7      //Arduino-MaxArm communication serial RX pin (Arduino与MaxArm通讯串口)
#define txPin 6      

//************* Data structure definition begin (数据结构定义 begin) *************

/*
 * 0xAA 0x55 | func | data_len | data | check
 */

#define CONST_STARTBYTE1 0xAAu
#define CONST_STARTBYTE2 0x55u


//Frame function ID enumeration (帧功能号枚举)
enum PACKET_FUNCTION {
  FUNC_SET_ANGLE = 0x01,
  FUNC_SET_XYZ = 0x03,
  FUNC_SET_PWMSERVO = 0x05,
  FUNC_SET_SUCTIONNOZZLE = 0x07,
  FUNC_READ_ANGLE = 0x11,
  FUNC_READ_XYZ = 0x13
};

//************* Data structure definition end (数据结构定义 end) ***************

class MaxArm_ctl {
  public:
    //Constructor (构造函数)
    MaxArm_ctl(void);

    //Serial start function (串口开启函数)
    void serial_begin(void);

    //Set bus servo angles (设置角度)
    void set_angles(uint8_t* angles , uint16_t time);

    //Set XYZ coordinates (设置xyz)
    void set_xyz(int16_t* pos , uint16_t time);

    //Set end-effector PWM servo angle (设置末端舵机角度)
    void set_pwmservo(uint8_t angle , uint16_t time);

    //Set suction nozzle function (设置喷嘴功能)
    void set_SuctioNnozzle(int func);

    // Read angles (读取角度)
    bool read_angles(int* angles);

    //Read XYZ coordinates (读取xyz)
    bool read_xyz(int* pos);

  private:
    bool rec_handle(uint8_t* res , uint8_t func);
};


#endif //MAXARM_CTL_H
