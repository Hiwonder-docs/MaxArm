from machine import Pin
import time
# The K1 button on the ESP32 expansion board is connected to IO25, and when K1 is pressed, it outputs a low level. Therefore, you need to set the IO25 pin to 
# pull-up input mode. (ESP32拓展板上的按键K1是连接到IO25上的，且按下K1后为低电平，所以我们要先设置IO25的引脚为上拉输入模式。)
key = Pin(25, Pin.IN, Pin.PULL_UP)
# Enter an infinite loop to continuously check whether the button is pressed. (进入死循环一直判断按键是否按下)
while True:
  # When the button is pressed, the level is low. (当按键按下时，为低电平)
  if key.value() == 0:
    # Delay 10ms to eliminate debounce. (延时10ms消除抖动)
    time.sleep_ms(10)
    # Check again whether the button is pressed. (再次判断按键是否按下)
    if key.value() == 0:
      # Output "hello world" via serial port. (串口输出hello world)
      print("hello world")
      # Exit the loop to end the program. (跳出死循环结束程序)
      led = Pin(2,Pin.OUT)
# To turn on the onboard LED, call the on() function to set IO2 high, and the LED will light up. (为了点亮板载LED要调用on函数使IO2为高电平，这时板载LED亮起)
      led.on()
      break




