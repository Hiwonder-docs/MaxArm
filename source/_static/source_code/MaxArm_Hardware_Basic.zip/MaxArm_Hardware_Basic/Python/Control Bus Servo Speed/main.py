import time
from BusServo import BusServo

# Control bus servo speed (控制总线舵机速度例程)

bus_servo = BusServo() 

if __name__ == '__main__':
  bus_servo.run(1, 500, 1500) # Move servo 1 to pulse 500, run time 1500 ms (设置1号舵机运行到500脉宽位置，运行时间为1500毫秒)
  time.sleep_ms(1500)         # Delay 1500 ms (延时1500毫秒)
  
  for t in (500, 2000):      # Run one cycle with different times, longer time means slower speed (分别以不同时间运行一轮，时间越长速度越慢)
    bus_servo.run(1, 600, t) # Move servo 1 to pulse 600 (设置1号舵机运行到600脉宽位置)
    time.sleep_ms(t)
    
    bus_servo.run(1, 500, t) # Move servo 1 to pulse 500 (设置1号舵机运行到500脉宽位置)
    time.sleep_ms(t)
    
    bus_servo.run(1, 400, t) # Move servo 1 to pulse 400 (设置1号舵机运行到400脉宽位置)
    time.sleep_ms(t)
    
    bus_servo.run(1, 500, t) # Move servo 1 to pulse 500 (设置1号舵机运行到500脉宽位置)
    time.sleep_ms(t)


