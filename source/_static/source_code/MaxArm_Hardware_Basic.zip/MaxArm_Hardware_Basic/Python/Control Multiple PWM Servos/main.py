import time
from PWMServo import PWMServo

# Control multiple PWM servos (控制多个PWM舵机)

pwm = PWMServo()
pwm.work_with_time()

if __name__ == '__main__':
  pwm.run(1, 500, 1000) # Set PWM servo 1 pulse width to 500, run time 1000 ms (设置1号PWM舵机脉宽500，运行时间1000毫秒(PWM舵机无法读取当前位置，所以首次运行，运行时间不可控))
  pwm.run(2, 500, 1000) # Set PWM servo 2 pulse width to 500, run time 1000 ms (设置2号PWM舵机脉宽500，运行时间1000毫秒)
  time.sleep_ms(2000)    # Delay 2000 ms (延时2000毫秒)
  
  pwm.run(1, 2500, 2000) # Set PWM servo 1 pulse width to 2500, run time 2000 ms (设置1号PWM舵机脉宽2500，运行时间2000毫秒)
  pwm.run(2, 2500, 2000) # Set PWM servo 2 pulse width to 2500, run time 2000 ms (设置2号PWM舵机脉宽2500，运行时间2000毫秒)
  time.sleep_ms(2000)    # Delay 2000 ms (延时2000毫秒)
  
  pwm.run(1, 500, 2000) # Set PWM servo 1 pulse width to 500, run time 2000 ms (设置1号PWM舵机脉宽500，运行时间2000毫秒)
  pwm.run(2, 500, 2000) # Set PWM servo 2 pulse width to 500, run time 2000 ms (设置2号PWM舵机脉宽500，运行时间2000毫秒)
  time.sleep_ms(2000)    # Delay 2000 ms (延时2000毫秒)


