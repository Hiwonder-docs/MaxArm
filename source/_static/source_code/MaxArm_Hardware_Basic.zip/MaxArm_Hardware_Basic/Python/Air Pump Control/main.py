import time
from SuctionNozzle import SuctionNozzle

# Control the air pump (控制气泵)

nozzle = SuctionNozzle()

if __name__ == '__main__':
  
  nozzle.on()          # Turn on the pump, close the solenoid valve at the same time (打开气泵，同时关闭电磁阀)
  time.sleep_ms(2000)  # Delay 2000 ms (延时2000毫秒)
  nozzle.off()         # Turn off the pump, open the solenoid valve at the same time (关闭气泵，同时打开电磁阀)
  







