from machine import Pin,ADC
import time
# Only IO33 and IO32 on our expansion board support ADC (在我们的拓展板上现有的IO口中只有IO33、IO32能够使用ADC功能)
adc = ADC(Pin(39))
# Set attenuation for full-scale voltage ~3.6V (设置衰减比，满量程约3.6V)
adc.atten(ADC.ATTN_11DB)
# Set data width to 10 bits, full scale 0~1023 (设置数据宽度为10bit，满量程0~1023)
adc.width(ADC.WIDTH_10BIT)
# Continuously read ADC value in a loop (在死循环中读取ADC数据)
while True:
  print(adc.read() / 1023 * 3.3 * 4)
  time.sleep_ms(100)
  












