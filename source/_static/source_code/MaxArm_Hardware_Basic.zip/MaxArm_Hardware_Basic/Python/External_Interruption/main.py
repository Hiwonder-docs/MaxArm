from machine import Pin
import time
# Initialize the LED and button according to Basic Tutorials 1 and 2 (按照基础教程1、2中初始化led和按键)
led = Pin(2,Pin.OUT)
key = Pin(13, Pin.IN, Pin.PULL_UP)
# Define the button interrupt callback function (定义按键中断回调函数)
def fun(key):
    time.sleep_ms(10) 
    if key.value()==0: 
        led.on()
        time.sleep_ms(1000)
#Define the button interrupt to trigger on the falling edge and set fun as the callback function (定义按键中断下降沿触发，并设置fun为回调函数)
key.irq(fun,Pin.IRQ_FALLING) 
#In the main loop, the LED remains off. When the button is pressed, the LED lights up for 1000 ms. (死循环中led灯为长灭状态，当按下按键led亮起1000ms。)
while True:
  led.off()
  time.sleep_ms(10) 

