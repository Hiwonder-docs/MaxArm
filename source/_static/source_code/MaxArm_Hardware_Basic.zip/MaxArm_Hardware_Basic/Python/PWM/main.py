from machine import Pin, PWM
import time
# Initialize PWM, Pin() is the IO port used, freq is the PWM frequency (初始化PWM，Pin()为所要调用的IO口，freq为PWM的频率)
# duty represents the PWM duty cycle range 0-1023 (duty代表PWM占空比范围为0-1023)
led =  PWM(Pin(2), freq=200, duty=0)
time.sleep_ms(500)

# Demonstrate with onboard LED, here duty represents brightness (板载LED来演示一下，这里duty代表的是亮度)
# The following program makes the LED gradually go from dark to bright and then from bright to dark, creating a breathing effect (以下程序会让LED灯逐渐的从暗到亮再从亮到暗，也就是呼吸灯)

for i in range(3): # Loop 3 times (循环3次)
  for i in range(0,1024,1): 
    led.duty(i)
    time.sleep_ms(2)
    
  for i in range(1023,0,-1):
    led.duty(i)
    time.sleep_ms(2)
  
led.duty(0) # Turn off LED (关闭LED)



