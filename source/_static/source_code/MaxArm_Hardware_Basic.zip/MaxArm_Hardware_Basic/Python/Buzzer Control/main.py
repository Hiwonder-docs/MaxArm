import time
from Buzzer import Buzzer

# Control the buzzer (控制蜂鸣器)

buzzer = Buzzer()

if __name__ == '__main__':
  buzzer.setBuzzer(100)  # Set the buzzer to sound for 100 ms (设置蜂鸣器响100毫秒)
  time.sleep_ms(1000)    # Delay 1000 ms (延时1000毫秒)
  buzzer.setBuzzer(300)  # Set the buzzer to sound for 300 ms (设置蜂鸣器响300毫秒)







