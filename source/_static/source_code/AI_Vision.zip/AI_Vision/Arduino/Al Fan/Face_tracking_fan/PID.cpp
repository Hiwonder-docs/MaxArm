#include "PID.h"

namespace arc{

  template class PID<double>;
  template class PID<float>;

}

